# Instructions  

  Write a program to have a person play the game of Hangman with the computer picking the word from an initialized array of 10 or more possible words. Use an array for the positions of each letter that is initialized to dashes. As each letter is guessed, check where it goes and fill in that dash with the letter. Also, keep track of an array of letters that were not correct so that each turn, you can print the word so far and the letters guessed so far.  Stop when you have 8 wrong guesses or when the word is guessed correctly. This loop is set up for you. 

Read through the comments to make sure you do what is asked. For example. At the start, tell the user how many letters long the word is. 

